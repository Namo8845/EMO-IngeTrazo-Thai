@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "SRC=%~dp0"
if not defined APPDATA (
  echo [ERROR] APPDATA was not found on this Windows account.
  goto failed
)
set "DEST=%APPDATA%\ingetrazo\plugins"
set "BACK=%APPDATA%\ingetrazo\EMO_Roof_Backup\install_frame_only_v55_%RANDOM%"
echo.
echo =========================================
echo EMO ROOF FRAME 5.5 FRAME ONLY BETA - INSTALLER
 echo =========================================
echo Source: "%SRC%"
echo Target: "%DEST%"
echo.
if not exist "%SRC%emo_roof_v5.py" (
  echo [ERROR] Missing emo_roof_v5.py in the extracted folder.
  echo Unzip the entire package first, do not run from inside ZIP.
  goto failed
)
if not exist "%SRC%_emo_roof_v5_geometry.py" (
  echo [ERROR] Missing _emo_roof_v5_geometry.py in the extracted folder.
  goto failed
)
if not exist "%DEST%\" mkdir "%DEST%"
if not exist "%DEST%\" (
  echo [ERROR] Unable to create plugin folder: "%DEST%"
  goto failed
)
if not exist "%BACK%\" mkdir "%BACK%"
if not exist "%BACK%\" (
  echo [ERROR] Unable to create backup folder.
  goto failed
)
echo [1/3] Backing up older EMO Roof plugins...
for %%F in ("%DEST%\emo_roof_v*.py") do (
  if exist "%%~fF" (
    copy /Y "%%~fF" "%BACK%\%%~nxF" >nul
    if errorlevel 1 goto failed
    del /F /Q "%%~fF" >nul
    if exist "%%~fF" goto failed
  )
)
if exist "%DEST%\_emo_roof_v5_geometry.py" (
  copy /Y "%DEST%\_emo_roof_v5_geometry.py" "%BACK%\_emo_roof_v5_geometry.py" >nul
  if errorlevel 1 goto failed
)
echo [2/3] Copying EMO Roof Frame v5.5 FRAME ONLY BETA...
copy /Y "%SRC%emo_roof_v5.py" "%DEST%\emo_roof_v5.py" >nul
if errorlevel 1 goto failed
copy /Y "%SRC%_emo_roof_v5_geometry.py" "%DEST%\_emo_roof_v5_geometry.py" >nul
if errorlevel 1 goto failed
echo [3/3] Verifying copied files...
fc /b "%SRC%emo_roof_v5.py" "%DEST%\emo_roof_v5.py" >nul
if errorlevel 1 goto failed
fc /b "%SRC%_emo_roof_v5_geometry.py" "%DEST%\_emo_roof_v5_geometry.py" >nul
if errorlevel 1 goto failed
echo.
echo [SUCCESS] EMO ROOF FRAME v5.5 FRAME ONLY BETA INSTALLED.
echo Backup: "%BACK%"
echo Open IngeTrazo ^> Extensions ^> EMO Roof Frame v5.5 FRAME ONLY BETA...
echo If it does not appear: use Extensions ^> Open plugins folder,
echo and check that the two Python files are present.
echo.
pause
exit /b 0
:failed
echo.
echo [FAILED] Installation stopped. Copy/screenshot this message.
echo For manual installation, read HOW_TO_INSTALL_TH.txt.
echo.
pause
exit /b 1
