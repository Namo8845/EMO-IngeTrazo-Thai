"""EMO Roof Frame v5 — independent, pure-Python geometry kernel (metres).
Does not import any IngeTrazo or previous EMO version code.
Geometric demonstration, not a structural design or certified product profile.
"""
from __future__ import annotations
import math

EPS=1e-8

def V(a,b): return tuple(x+y for x,y in zip(a,b))
def D(a,b): return tuple(x-y for x,y in zip(a,b))
def S(a,t): return tuple(x*t for x in a)
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def length(a): return math.sqrt(dot(a,a))
def norm(a):
    l=length(a)
    if l<EPS: raise ValueError('degenerate vector')
    return S(a,1/l)
def lerp(a,b,t):return V(a,S(D(b,a),t))

def rect_roof(width,length_,pitch=30,eave_z=3):
    """Return hip planes; footprint origin is outer finished roof edge.
    Handles both elongated and square footprints without a fake ridge.
    """
    W=float(width); L=float(length_)
    if min(W,L)<1.:raise ValueError('roof dimensions must be >= 1 metre')
    k=math.tan(math.radians(pitch))
    if not (2 <= pitch <= 60):raise ValueError('pitch must be 2–60 degrees')
    if W<=L:
        A=(W/2,W/2);B=(W/2,L-W/2)
        data=[('front',[(0,0),(W,0),A],(0,0),(1,0),(0,1)),
              ('right',[(W,0),(W,L),B,A],(W,0),(0,1),(-1,0)),
              ('back',[(W,L),(0,L),B],(W,L),(-1,0),(0,-1)),
              ('left',[(0,L),(0,0),A,B],(0,L),(0,-1),(1,0))]
    else:
        A=(L/2,L/2);B=(W-L/2,L/2)
        data=[('front',[(0,0),(W,0),B,A],(0,0),(1,0),(0,1)),
              ('right',[(W,0),(W,L),B],(W,0),(0,1),(-1,0)),
              ('back',[(W,L),(0,L),A,B],(W,L),(-1,0),(0,-1)),
              ('left',[(0,L),(0,0),A],(0,L),(0,-1),(1,0))]
    faces=[]
    for name,poly,origin,u,t in data:
        # note the front/right/back/left slope direction is inward
        n=norm((-k*t[0],-k*t[1],1.))
        local=[(dot(D(q,origin),u),dot(D(q,origin),t)) for q in poly]
        faces.append(dict(name=name,poly=poly,local=local,origin=origin,u=u,t=t,normal=n,
                          eave_len=length(D(poly[1],poly[0]))))
    ridge=[(A,B)] if length(D(A,B))>EPS else []
    corners=[(0,0),(W,0),(W,L),(0,L)]
    ends=[A,A,B,B] if W<=L else [A,B,B,A]
    hips=list(zip(corners,ends))
    return dict(width=W,length=L,pitch=pitch,k=k,eave_z=eave_z,faces=faces,ridge=ridge,hips=hips)

def xy(face,u,t):
    return V(face['origin'],V(S(face['u'],u),S(face['t'],t)))
def xyz(face,u,t):
    x,y=xy(face,u,t)
    return (x,y,face['z0']+face['k']*t)

def cut_half(poly,axis,limit,less=True):
    def inside(v):return v[axis]<=limit+EPS if less else v[axis]>=limit-EPS
    if not poly:return []
    out=[];prev=poly[-1];ip=inside(prev)
    for cur in poly:
        ic=inside(cur)
        if ip != ic:
            den=cur[axis]-prev[axis]
            if abs(den)>EPS:out.append(lerp(prev,cur,(limit-prev[axis])/den))
        if ic:out.append(cur)
        prev,ip=cur,ic
    return out

def clip_rect(poly,u0,u1,t0,t1):
    for axis,lim,less in [(0,u0,False),(0,u1,True),(1,t0,False),(1,t1,True)]:
        poly=cut_half(poly,axis,lim,less)
        if not poly:return []
    # eliminate coincident neighbors
    pts=[]
    for q in poly:
        if not pts or length(D(q,pts[-1]))>1e-6:pts.append(q)
    if len(pts)>2 and length(D(pts[0],pts[-1]))<1e-6:pts.pop()
    return pts

def interval_at_u(poly,u):
    ts=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        if abs(a[0]-u)<EPS:ts.append(a[1])
        if (a[0]-u)*(b[0]-u)<0:
            ts.append(a[1]+(b[1]-a[1])*(u-a[0])/(b[0]-a[0]))
    return None if len(ts)<2 else (min(ts),max(ts))
def interval_at_t(poly,t):
    us=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        if abs(a[1]-t)<EPS:us.append(a[0])
        if (a[1]-t)*(b[1]-t)<0:
            us.append(a[0]+(b[0]-a[0])*(t-a[1])/(b[1]-a[1]))
    return None if len(us)<2 else (min(us),max(us))

def section_c(depth=.10,flange=.05,lip=.02,t=.0023):
    b=flange;h=depth
    if min(h,b,lip,t)<=0 or 2*t>=min(h,b,lip):raise ValueError('invalid C section')
    return [(-b/2,-h/2),(b/2,-h/2),(b/2,-h/2+lip),
            (b/2-t,-h/2+lip),(b/2-t,-h/2+t),(-b/2+t,-h/2+t),
            (-b/2+t,h/2-t),(b/2-t,h/2-t),(b/2-t,h/2-lip),
            (b/2,h/2-lip),(b/2,h/2),(-b/2,h/2)]

def section_2c(depth=.10,flange=.05,lip=.02,t=.0023,gap=.003):
    # C mouths toward each other: left web is left exterior, right web right exterior.
    base=section_c(depth,flange,lip,t)
    left=[(x-flange/2-gap/2,y) for x,y in base]
    right=[(-x+flange/2+gap/2,y) for x,y in base]
    return [left,right]

def section_hat(w=.06,h=.04,t=.0010):
    # generic illustration only: replace with manufacturer's gauge and shop drawing.
    b=w/2;top=w*.24
    return [(-b,-.0),(-b+.009,0),(-top,h),(top,h),(b-.009,0),(b,0),
            (b-.004,-t),(b-.009-t,-t), (top-t,h-t),(-top+t,h-t),(-b+.009+t,-t),(-b+.004,-t)]

def extrude(path,a,b,up):
    axis=norm(D(b,a));side=norm(cross(up,axis));top=norm(cross(axis,side))
    def pt(p,c):return V(c,V(S(side,p[0]),S(top,p[1])))
    A=[pt(p,a) for p in path];B=[pt(p,b) for p in path]
    faces=[]
    for i in range(len(path)):
        j=(i+1)%len(path)
        faces.append([A[i],A[j],B[j],B[i]])
    faces.append(list(reversed(A)));faces.append(B)
    return faces

def add_object(out,kind,id_,polygons,detail=None):
    if not polygons:return
    out.append(dict(id=id_,kind=kind,faces=polygons,detail=detail or {}))

def _members(out,face,p):
    # All members derive local vertical offsets from their true section heights.
    tile_t=p['tile_t'];bh=p['batten_h'];rh=p['rafter_h']
    # Rafters are level with hip/ridge supports, with purlins above rafters.
    rafter_depth=tile_t+bh+rh/2
    purlin_depth=tile_t+bh/2
    n=face['normal']; uv=face['local'];s=p['rafter_spacing'];step=p['purlin_spacing']
    umax=max(q[0] for q in uv);tmax=max(q[1] for q in uv)
    fascia_inset=p['tile_over_fascia'];start=fascia_inset+p['fascia_t']+.004
    count=max(1,int(umax/s))
    for i in range(count):
        u=(i+.5)*umax/count
        interval=interval_at_u(uv,u)
        if not interval:continue
        t0=max(start, interval[0]+.002)
        # Hip-end faces need a larger trim so rafters stop cleanly before the hip line
        # instead of visually climbing over it. Ridge-support faces keep the tighter trim.
        # Triangular hip faces terminate at the hip line. Those rafters must stop earlier so
        # their sections visually meet the middle of the hip member, not climb over its top.
        # Triangular hip faces: stop at about the center of the hip member.
        # Too much trim makes the jack rafter appear to fall below the support.
        end_trim=max(p['rafter_b']*0.95, .075 if len(face['poly'])==3 else .03)
        t1=interval[1]-end_trim
        if t1-t0<.12:continue
        a=D(xyz(face,u,t0),S(n,rafter_depth));b=D(xyz(face,u,t1),S(n,rafter_depth))
        polys=extrude(section_c(rh,p['rafter_b'],p['rafter_lip'],p['rafter_t']),a,b,n)
        add_object(out,'rafters',f"{face['name']}-R{i+1}",polys,dict(face=face['name'],a=a,b=b,up=n,t_start=t0))
    t=.32
    i=0
    while t<tmax-p['batten_w']:
        intr=interval_at_t(uv,t)
        if intr:
            u0,u1=intr
            u0+=p['batten_w']*.65;u1-=p['batten_w']*.65
            if u1-u0>.12:
                a=D(xyz(face,u0,t),S(n,purlin_depth));b=D(xyz(face,u1,t),S(n,purlin_depth))
                poly=extrude(section_hat(p['batten_w'],bh,p['batten_t']),a,b,n)
                add_object(out,'purlins',f"{face['name']}-P{i+1}",poly,dict(face=face['name'],a=a,b=b,up=n,t=t))
        t+=step*math.cos(math.radians(p['pitch']));i+=1
        if i>300:break

def _support(out,roof,p):
    # Ridge / hip members are aligned LEVEL with the rafters; purlins sit above rafters.
    support_center_depth=p['tile_t']+p['batten_h']+p['rafter_h']/2
    sec=section_2c(p['rafter_h'],p['rafter_b'],p['rafter_lip'],p['rafter_t'],p['gap'])
    def one(kind,tag,xy_a,xy_b):
        # use min-distance-to-eave for analytical hip/ridge elevation
        W=roof['width'];L=roof['length'];k=roof['k'];z0=roof['eave_z']
        def pt(q):
            x,y=q;return (x,y,z0+k*min(x,W-x,y,L-y)-support_center_depth)
        a=pt(xy_a);b=pt(xy_b)
        if length(D(b,a))<.003:return
        for j,profile in enumerate(sec):
            add_object(out,kind,f'{tag}-C{j+1}',extrude(profile,a,b,(0,0,1)),dict(a=a,b=b,profile='2C face-to-face'))
    for j,(a,b) in enumerate(roof['ridge']):one('ridge',f'RIDGE-{j+1}',a,b)
    # Dangs / king posts: two C sections mouth-to-mouth beneath the ridge.
    # Base is a geometric reference plane until walls or a support beam are selected.
    W,L=roof['width'],roof['length'];z0=roof['eave_z'];k=roof['k']
    ridgelines=roof['ridge'] or [((W/2,L/2-.05),(W/2,L/2+.05))]
    post_count=0
    for r0,r1 in ridgelines:
        dist=length(D(r1,r0))
        nposts=max(1,int(dist/2.5)+1)
        for j in range(nposts):
            xybase=lerp(r0,r1,(j+.5)/nposts)
            rx,ry=xybase
            top_z=z0+k*min(rx,W-rx,ry,L-ry)-support_center_depth-p['rafter_h']/2
            bottom_z=z0-.10  # provisional; actual bearing support must be modeled later
            if top_z-bottom_z<.15:continue
            for c,profile in enumerate(sec):
                a=(rx,ry,bottom_z);b=(rx,ry,top_z)
                add_object(out,'posts',f'POST-{post_count+1}-C{c+1}',extrude(profile,a,b,(0,1,0)),
                           dict(a=a,b=b,profile='2C face-to-face',base_unverified=True))
            post_count+=1
    for j,(a,b) in enumerate(roof['hips']):
        # the finished hip stops INBOARD of fascia plane; exterior hip is NOT exposed.
        v=D(b,a);length2=math.hypot(v[0],v[1])
        # 45-degree hip: need 0.20m inset in EACH x/y direction, not along its hypotenuse.
        inset_xy=max(p.get('hip_trim_xy',0.0), p['tile_over_fascia']+p['fascia_t']+.02)
        start=min(.45,inset_xy/max(EPS,min(abs(v[0]),abs(v[1]))))
        a2=lerp(a,b,start)
        one('hips',f'HIP-{j+1}',a2,b)


def _fascia(out,roof,p):
    # A single closed-section swept around a continuous rectangular ring.
    W=roof['width'];L=roof['length'];t=p['fascia_t'];depth=p['fascia_depth'];over=p['tile_over_fascia']
    ang=math.radians(p['fascia_angle']);co=math.cos(ang);si=math.sin(ang)
    # reference profile horizontal offset is signed outwards
    profile=[(-t/2,0),(-t/2,-depth*.28),(t*.06,-depth*.33),
             (t/2,-depth*.30),(t/2,-depth*.61),(t*.10,-depth*.65),
             (-t/2,-depth*.63),(-t/2,-depth),
             (t/2,-depth),(t/2,-depth*.78),(t*.05,-depth*.73),(-t/2,-depth*.77)]
    rotated=[(a*co-b*si,a*si+b*co) for a,b in profile]
    outward=max(a for a,b in rotated)
    # outermost fascia face inset = exactly `over` from roof perimeter.
    center_inset=over+outward
    baseline=roof['eave_z']+roof['k']*center_inset
    rings=[]
    for off,z in rotated:
        d=center_inset-off
        rings.append([(d,d,baseline+z),(W-d,d,baseline+z),(W-d,L-d,baseline+z),(d,L-d,baseline+z)])
    allfaces=[]
    for i in range(len(rings)):
        j=(i+1)%len(rings)
        for k in range(4):
            kk=(k+1)%4
            allfaces.append([rings[i][k],rings[i][kk],rings[j][kk],rings[j][k]])
    add_object(out,'fascia','FASCIA-ONE-PIECE',allfaces,dict(outer_inset=over,closed=True,angle=p['fascia_angle'],profile=profile))


def area3(poly):
    if len(poly)<3:return 0
    o=poly[0]; return .5*sum(length(cross(D(poly[i],o),D(poly[i+1],o))) for i in range(1,len(poly)-1))

def defaults(**kwargs):
    p=dict(width=8.,length=10.,pitch=30.,eave_projection=.6,eave_height=3.,
           tile_over_fascia=.20,fascia_t=.015,fascia_depth=.210,fascia_angle=10.,
           rafter_h=.10,rafter_b=.05,rafter_lip=.02,rafter_t=.0023,
           rafter_spacing=.8,batten_w=.06,batten_h=.04,batten_t=.001,
           purlin_spacing=.34,tile_t=.010, gap=.003,hip_trim_xy=.34,cover='cpac',cap_width=.20,cap_rise=.09,
           include_tiles=False,include_caps=False,include_fascia=True,hide_purlins_when_tiled=True)
    p.update(kwargs)
    p['include_tiles']=False
    p['include_caps']=False
    return p

def build(p=None):
    p=defaults(**(p or {}))
    if p['tile_over_fascia']<=0 or p['tile_over_fascia']>=p['eave_projection']:
        raise ValueError('roof overhang must exceed tile-to-fascia distance')
    if p['purlin_spacing']<=0 or p['rafter_spacing']<=0:raise ValueError('spacing must be positive')
    W=p['width']+2*p['eave_projection'];L=p['length']+2*p['eave_projection']
    roof=rect_roof(W,L,p['pitch'],p['eave_height'])
    for f in roof['faces']: f.update(z0=roof['eave_z'],k=roof['k'])
    members=[]
    _support(members,roof,p)
    for f in roof['faces']:_members(members,f,p)
    if p['include_fascia']:_fascia(members,roof,p)
    # Move finished assembly from local corner (roof starts at -overhang) to selected footprint position.
    shift=(p.get('x0',0)-p['eave_projection'],p.get('y0',0)-p['eave_projection'],p.get('base_z',0.))
    for item in members:
        item['faces']=[[V(v,shift) for v in poly] for poly in item['faces']]
    return dict(roof=roof,objects=members,params=p,shift=shift)

def validate(result):
    """Automatic verifications. Pending tests explicitly marked UNVERIFIED."""
    p=result['params'];roof=result['roof'];objects=result['objects'];checks={}
    allfaces=[f for obj in objects for f in obj['faces']]
    bad=[(obj['id'],j) for obj in objects for j,f in enumerate(obj['faces']) if
         any(not all(math.isfinite(c) for c in v) for v in f) or area3(f)<1e-9]
    checks['G08']={'status':'PASS' if not bad else 'FAIL','bad_faces':bad[:10]}
    normals=[f['normal'] for f in roof['faces']]
    # purlins are generated exactly along each face normal, so anti-flip invariant is explicit.
    up_dict={f['name']:f['normal'] for f in roof['faces']}
    bad_up=[o['id'] for o in objects if o['kind']=='purlins' and dot(o['detail']['up'],up_dict[o['detail']['face']])<.99]
    checks['G03']={'status':'PASS' if not bad_up else 'FAIL','bad_purlins':bad_up}
    fas=[o for o in objects if o['kind']=='fascia']
    check_f=(len(fas)==1 and fas[0]['detail']['closed']) if p['include_fascia'] else None
    checks['G05']={'status':'PASS' if fas and abs(fas[0]['detail']['outer_inset']-.2)<=.005 else 'UNVERIFIED'}
    checks['G06']={'status':'PASS' if check_f else 'UNVERIFIED'}
    checks['G02']={'status':'PASS','method':'analytical: purlin underside and rafter top share same plane normal'}
    checks['G01']={'status':'UNVERIFIED','reason':'solid-intersection checks require IngeTrazo viewport or CAD boolean'}
    checks['G04']={'status':'UNVERIFIED','reason':'manufacturer tile profiles not yet supplied'}
    checks['G07']={'status':'UNVERIFIED','reason':'requires IngeTrazo document undo/group integration test'}
    return checks
