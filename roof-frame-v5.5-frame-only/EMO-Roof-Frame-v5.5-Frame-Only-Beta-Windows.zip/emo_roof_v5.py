"""EMO Roof Frame 5.5 FRAME ONLY BETA: IngeTrazo extension.
SPDX-License-Identifier: MIT
Independent Python geometry; use in IngeTrazo 0.x at user's own risk.
"""
from __future__ import annotations
import importlib.util
from pathlib import Path
import uuid
import math
import traceback

from PySide6.QtGui import QVector3D
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QFormLayout, QHBoxLayout,
    QDoubleSpinBox, QComboBox, QPushButton, QLabel, QCheckBox, QMessageBox,
    QGroupBox, QScrollArea)
from core.group import Group
from core.mesh import Mesh, Face
from core.history import Command

KEY='emo_roof_v5'
_kernel_path=Path(__file__).with_name('_emo_roof_v5_geometry.py')
_spec=importlib.util.spec_from_file_location('_emo_roof_v5_geometry',str(_kernel_path))
if _spec is None or _spec.loader is None:
    raise RuntimeError('Missing geometry file: '+str(_kernel_path))
G=importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(G)

KINDS=['ridge','hips','posts','rafters','purlins','fascia']
NAMES={'ridge':'อกไก่ 2C','hips':'สันเข้า 2C','rafters':'จันทัน C','purlins':'แปกัลวาไนซ์',
       'posts':'ดั้ง 2C (ฐานจำลอง)','fascia':'เชิงชาย 2-in-1'}
COLORS={'ridge':(.41,.49,.58),'hips':(.42,.52,.62),'rafters':(.60,.66,.71),
        'purlins':(.40,.46,.51),'posts':(.49,.54,.58),'fascia':(.86,.86,.82)}

class RoofChange(Command):
    """Group replacement is one undoable change, including all child groups."""
    def __init__(self, root):
        self.root=root;self.previous=[];self.idx=None
    def do(self,scene):
        self.previous=[(i,g) for i,g in enumerate(scene.groups)
                       if isinstance(getattr(g,'ext',None),dict)
                       and g.ext.get(KEY,{}).get('assembly')]
        if self.previous:
            self.idx=min(i for i,_ in self.previous)
        else:self.idx=len(scene.groups)
        for _,g in reversed(self.previous):
            if g in scene.groups:scene.groups.remove(g)
        scene.groups.insert(min(self.idx,len(scene.groups)),self.root)
        scene.version+=1
    def undo(self,scene):
        if self.root in scene.groups:scene.groups.remove(self.root)
        for i,g in sorted(self.previous,key=lambda x:x[0]):
            scene.groups.insert(min(i,len(scene.groups)),g)
        scene.version+=1

class RoofVisibility(Command):
    def __init__(self,group,visible):self.group=group;self.visible=bool(visible);self.was=None
    def do(self,scene):
        if self.was is None:self.was=self.group.hidden
        self.group.hidden=not self.visible;scene.version+=1
    def undo(self,scene):self.group.hidden=self.was;scene.version+=1

def root_in(scene):
    for g in scene.groups:
        ext=getattr(g,'ext',None) or {}
        if isinstance(ext,dict) and ext.get(KEY,{}).get('assembly'):
            return g
    return None

def face_bounds(scene):
    fs=[x for x in scene.selection if isinstance(x,Face) and x in scene.mesh.faces]
    if not fs:return None
    f=fs[0]
    v=f.vertices
    if len(v)!=4:raise ValueError('เลือกผิวสี่เหลี่ยมแนวราบเพียงหนึ่งผืน')
    X=[a.x() for a in v];Y=[a.y() for a in v];Z=[a.z() for a in v]
    if max(Z)-min(Z)>.005:raise ValueError('ผิวที่เลือกต้องเป็นแนวราบ (ระดับ Z เดียวกัน)')
    dx=max(X)-min(X);dy=max(Y)-min(Y)
    if min(dx,dy)<1:raise ValueError('ผิวฐานต้องกว้างและยาวไม่น้อยกว่า 1 เมตร')
    # Reject non-rectangles, not silently fitting an inaccurate bounding box.
    for a in v:
        if not (min(abs(a.x()-min(X)),abs(a.x()-max(X)))<.005 and
                min(abs(a.y()-min(Y)),abs(a.y()-max(Y)))<.005):
            raise ValueError('รองรับเฉพาะผิวสี่เหลี่ยมขนานแกน X/Y ในรุ่นนี้')
    return dict(width=dx,length=dy,x0=min(X),y0=min(Y),base_z=min(Z))

def create_root(model):
    # Group by part, not by every tile: visible/editable hierarchy + avoids UI explosion.
    root=Group(name='EMO Roof v5.5 FRAME ONLY BETA | ปั้นหยา')
    root.ext={KEY:{'assembly':True,'schema':11,'params':model['params'],
                   'instance_id':str(uuid.uuid4()),'verified_windows':False}}
    by_kind={k:[] for k in KINDS}
    for obj in model['objects']:by_kind[obj['kind']].extend(obj['faces'])
    for kind in KINDS:
        polys=by_kind[kind]
        if not polys:continue
        mesh=Mesh()
        col=COLORS[kind]
        for poly in polys:
            if len(poly)<3 or G.area3(poly)<1e-9:continue
            face=mesh.add_face([QVector3D(float(x),float(y),float(z)) for x,y,z in poly])
            if face is not None:face.attrs={'color':col}
        child=Group(mesh,name=NAMES[kind])
        child.ext={KEY:{'type':kind,'assembly_id':root.ext[KEY]['instance_id']}}
        root.children.append(child)
    return root

class RoofPanel(QWidget):
    def __init__(self,app):
        super().__init__()
        self.app=app;self.controls={};self.checked={}
        layout=QVBoxLayout(self)
        info=QLabel('EMO ROOF FRAME v5.5 FRAME ONLY BETA\nเฉพาะโครงปั้นหยา · อกไก่ / สันเข้า / ดั้ง / จันทัน / แป / เชิงชาย')
        info.setWordWrap(True);layout.addWidget(info)
        scroll=QScrollArea();scroll.setWidgetResizable(True)
        inner=QWidget();form=QFormLayout(inner)
        fields=[('กว้างอาคาร (ม.)','width',8,1,80),('ยาวอาคาร (ม.)','length',10,1,80),
                ('ความลาดชัน (องศา)','pitch',30,2,60),('ชายคายื่นจากผนัง (ม.)','eave_projection',.6,.25,5),
                ('ระดับชายคา (ม.)','eave_height',3,0,40),('ระยะขอบหลังคาถึงเชิงชาย (ม.)','tile_over_fascia',.20,.05,.8),
                ('ระยะจันทัน (ม.)','rafter_spacing',.8,.2,2),('ระยะแปตามลาด (ม.)','purlin_spacing',.34,.20,2),
                ('องศาเชิงชาย','fascia_angle',10,-30,30),('ความกว้างหน้าเชิงชาย (ม.)','fascia_depth',.210,.10,.5)]
        for label,key,value,low,high in fields:
            s=QDoubleSpinBox();s.setDecimals(3);s.setRange(low,high);s.setValue(value)
            s.setSingleStep(.05 if key not in ('pitch','fascia_angle') else 1)
            self.controls[key]=s;form.addRow(label,s)
        self.fascia=QCheckBox('สร้างเชิงชายชิ้นเดียว');self.fascia.setChecked(True)
        form.addRow(self.fascia)
        scroll.setWidget(inner);layout.addWidget(scroll)
        note=QLabel('ถ้าเลือกผิวพื้นสี่เหลี่ยมในโมเดล จะใช้ระยะจริงจากผิวนั้นแทนช่องกว้าง/ยาว\n'
                    'BETA: เฉพาะโครงเหล็ก ไม่รวมกระเบื้องหรือครอบ และไม่ใช่แบบวิศวกรรมรับรอง')
        note.setWordWrap(True);layout.addWidget(note)
        btn=QPushButton('สร้าง / สร้างใหม่ (Undo ได้)')
        btn.clicked.connect(self.create);layout.addWidget(btn)
        b2=QPushButton('ตรวจสอบ 3 แบบมาตรฐาน')
        b2.clicked.connect(self.test);layout.addWidget(b2)
        grp=QGroupBox('ซ่อน / แสดงชิ้นงานหลังสร้าง')
        gform=QVBoxLayout(grp)
        for kind in KINDS:
            c=QCheckBox(NAMES[kind]);c.setChecked(True)
            c.clicked.connect(lambda checked,k=kind:self.set_visible(k,checked))
            gform.addWidget(c);self.checked[kind]=c
        layout.addWidget(grp)
        self.app.on_document_changed(self.refresh)
        self.refresh()

    def params(self):
        p={key:ctrl.value() for key,ctrl in self.controls.items()}
        p.update(include_tiles=False,include_caps=False,include_fascia=self.fascia.isChecked())
        return p

    def create(self):
        try:
            if self.app.viewport.scene.edit_group is not None:
                raise ValueError('ออกจากโหมดแก้ไข Group ก่อนสร้างหลังคา')
            p=self.params()
            selected=face_bounds(self.app.viewport.scene)
            if selected:p.update(selected)
            model=G.build(p)
            checks=G.validate(model)
            if any(v['status']=='FAIL' for v in checks.values()):
                raise ValueError('ไม่ผ่านการตรวจเลขเรขาคณิต: '+str(checks))
            root=create_root(model)
            self.app.viewport.history.execute(RoofChange(root))
            self.app.viewport.notify_scene_changed()
            self.refresh()
            QMessageBox.information(self,'EMO Roof Frame v5.5 Frame Only' ,
                'สร้างโมเดลใหม่แล้ว: '+str(len(model['objects']))+' สมาชิก\n'
                'ผ่าน G02, G03, G05, G06, G08 บน Python\n'
                'G01/G04/G07 ยังรอตรวจเพิ่มใน IngeTrazo และข้อมูลผู้ผลิตจริง')
        except Exception as exc:
            QMessageBox.critical(self,'EMO Roof Frame — Error',str(exc)+'\n\n'+traceback.format_exc()[-1500:])

    def refresh(self):
        root=root_in(self.app.viewport.scene)
        for k,c in self.checked.items():
            target=next((g for g in root.children if (g.ext or {}).get(KEY,{}).get('type')==k),None) if root else None
            c.blockSignals(True);c.setEnabled(target is not None)
            c.setChecked(target is not None and not target.hidden);c.blockSignals(False)

    def set_visible(self,kind,value):
        root=root_in(self.app.viewport.scene)
        if not root:return
        target=next((g for g in root.children if (g.ext or {}).get(KEY,{}).get('type')==kind),None)
        if not target:return
        self.app.viewport.history.execute(RoofVisibility(target,value))
        self.app.viewport.notify_scene_changed()

    def test(self):
        cases=[('H01',8,10,30,.6),('H02',9,9,20,.6),('H03',6,12,40,.8)]
        results=[]
        try:
            for name,w,l,pitch,e in cases:
                model=G.build(dict(width=w,length=l,pitch=pitch,eave_projection=e))
                checks=G.validate(model)
                results.append(name+': '+', '.join(k+'='+v['status'] for k,v in sorted(checks.items())))
            QMessageBox.information(self,'EMO v5 — สรุปตรวจเรขาคณิต',
                '\n'.join(results)+'\n\nUNVERIFIED หมายถึงยังไม่ผ่านการตรวจรับบน Windows')
        except Exception as exc:
            QMessageBox.critical(self,'EMO Test Failed',str(exc))

def setup(app):
    panel=RoofPanel(app)
    dock=app.add_panel('EMO Roof Frame v5.5 FRAME ONLY BETA',panel,name='roof_v55_frame_only')
    app.add_menu_action('EMO Roof Frame v5.5 FRAME ONLY BETA…',lambda:app.show_panel(dock),
                        tip='สร้างโครงหลังคาปั้นหยาใหม่และเปิดการซ่อน/แสดง Group')
