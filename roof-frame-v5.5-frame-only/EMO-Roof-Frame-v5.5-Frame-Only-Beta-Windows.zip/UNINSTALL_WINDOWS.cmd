@echo off
set "DEST=%APPDATA%\ingetrazo\plugins"
if exist "%DEST%\emo_roof_v5.py" del /F /Q "%DEST%\emo_roof_v5.py"
if exist "%DEST%\_emo_roof_v5_geometry.py" del /F /Q "%DEST%\_emo_roof_v5_geometry.py"
echo EMO Roof v5.x removed. Backups in %%APPDATA%%\ingetrazo\EMO_Roof_Backup
pause
